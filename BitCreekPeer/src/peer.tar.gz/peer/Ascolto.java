package peer;

import condivisi.ErrorException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * Task che si occupa di ascoltare richieste sulla porta di ricezione
 * @author Bandettini
 */
public class Ascolto implements Runnable {

    /* Costanti */
    private final int ATTESA = 3000;

    /* Variabili d'istanza */
    private BitCreekPeer peer;

    /**
     * Costruttore
     */
    public Ascolto(BitCreekPeer peer) throws ErrorException{
        if( peer == null) throw new ErrorException("Param null");
        this.peer = peer;
    }

    /**
     * Corpo del task
     */
    public void run() {
        while (true) {
            try {
                peer.getIpServer().getHostAddress();
                    try {
                        Socket scambio = peer.getSS().accept();
                    // creo thread per gestire scambio
                    // lo aggiungo al thread pool
                    } catch (SocketTimeoutException e) {
                        // timeout scaduto : continuo a ciclare
                    } catch (IOException ex) {
                        System.err.println("Sono stato disconnesso : la socket di benvenuto è stata chiusa");
                    }
            } catch (NullPointerException e) {
                /* ipServer è null --> sono disconnesso quindi aspetto */
                try {
                    Thread.sleep(ATTESA);
                } catch (InterruptedException ex) {
                    System.err.println("Interrotto thread Ascolto");
                }
            }
        }
    }
}
