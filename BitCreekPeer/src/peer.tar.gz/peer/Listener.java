
package peer;

import java.net.ServerSocket;

/**
 * Thread di ascolto della ServerSocket di un peer
 * @author andrea
 */
public class Listener implements Runnable{
    
    ServerSocket ss;
    
    public Listener(ServerSocket ss){
        this.ss = ss;
    }

    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
