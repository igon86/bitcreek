
package peer;

/**
 * Informazioni relative ad un chunk da scaricare
 * @author andrea
 */
public class PIO {

    private int id;
    private int rarita;
    private boolean busy;
    
    public PIO(int id){
        this.id = id;
        this.rarita = 0;
        this.busy = false;
    }
    
    //getter
    public int getId(){
        return this.id;
    }
    
    public int getRarita(){
        return this.rarita;
    }
    
    //setter
    public void setRarita(int rarita){
        this.rarita = rarita;
    }
    
    public void setFree(){
        this.busy = false;
    }
    
    public void setBusy(){
        this.busy = true;
    }
}


