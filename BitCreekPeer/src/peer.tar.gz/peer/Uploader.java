
package peer;

/**
 *
 * @author andrea
 */
public class Uploader implements Runnable{
    
    Connessione conn;
    
    public Uploader(Connessione conn){
        this.conn = conn;
    }

    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
