
package peer;

/**
 *
 * @author andrea
 */
public class Avvia implements Runnable{
    
    public Avvia(){
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void run() {
             for (int index : array) {
            Creek c = new Creek(cercati.get(index), true, false); //true perchè il file è in download,false perchè non lo ho pubblicato

            addCreek(c);

            //recupero della lista Peer dal tracker
            int portatracker = cercati.get(index).getTCP();
            System.out.println("porta tracker : " + portatracker);
            try {
                s = (SSLSocket) SSLSocketFactory.getDefault().createSocket(ipServer, portatracker);
                oin = new ObjectInputStream(s.getInputStream());
                lista = new ArrayList<NetRecord>();
                // leggo la dimensione della lista
                dimlista = oin.readInt();
                System.out.println("dimlista : " + dimlista);
                // faccio un for per leggere i netrecord
                for (int j = 0; j < dimlista; j++) {
                    lista.add((NetRecord) oin.readObject());
                }
                riga.setPeer(dimlista);
                riga.setLista(lista);
                s.close();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BitCreekPeer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(BitCreekPeer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
