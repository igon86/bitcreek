package peer;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Classe che virtualizza la Connessione tra 2 peer facenti parte di uno swarm
 * @author andrea
 */
public class Connessione {
    
    //l'oggetto connessione e` l'unico abilitato ad inviare messaggi sulle socket
    Socket down;
    Socket up;
    
    ObjectInputStream inDown;
    ObjectOutputStream outDown;
    ObjectInputStream inUp;
    ObjectOutputStream outUp;
            
    
    boolean statoDown;
    boolean statoUp;
    
    boolean interesseDown;
    boolean interesseUp;
    
    boolean[] bitfield;
    int downloaded;
    
    public Connessione(){
        throw new UnsupportedOperationException();
    }
    
    //Virtualizzazione
    public synchronized void sendDown(){
        throw new UnsupportedOperationException();
    }
    
    public synchronized void sendUp(){
        throw new UnsupportedOperationException();
    }
    
    public synchronized Messaggio receiveDown(){
        throw new UnsupportedOperationException();
    }
    
    public synchronized Messaggio receiveUp(){
        throw new UnsupportedOperationException();
    }
    
    //getter
    public boolean getStatoDown(){
        return this.statoDown;
    }
    
    public boolean getStatoUp(){
        return this.statoUp;
    }
    
    public boolean getInteresseDown(){
        return this.interesseDown;
    }
    
    public boolean getInteresseUp(){
        return this.interesseUp;
    }
}
