
package peer;

/**
 *
 * @author andrea
 */
public class Downloader implements Runnable{
    
    private Creek c;
    
    public Downloader(Creek c){
        this.c = c;
    }

    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
