
package peer;

import java.io.Serializable;

/**
 *
 * @author andrea
 */
public class Messaggio implements Serializable{
    
     public static final long serialVersionUID = 67;

    private int tipo;
    private Object corpo;
    
    public Messaggio(int tipo, Object corpo){
        this.tipo = tipo;
        this.corpo = corpo;
    }
    
    //getter
    public int getTipo(){
        return this.tipo;
    }
    
    public Object getObj(){
        return this.corpo;
    }
    
    //non c'e` alcun bisogno dei setter
    
}
